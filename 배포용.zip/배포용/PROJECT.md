# 조이 월드 마인크래프트 서버 프로젝트

> 이 문서는 claude.ai 채팅에서 방향을 잡은 내용을 정리한 것입니다.
> Claude Code에서 작업을 이어갈 때 이 파일을 먼저 읽고 시작하세요.

## 프로젝트 개요

마크 모드팩("Fantasy MC Fabric")을 기반으로 커스텀 MMO풍 RPG 서버를 구축.
직업/스킬 시스템, 장비 강화, 경제(페소), 펫, PvP 배팅장, 부동산, 던전 등을 포함.
세계관: "조이 월드"에 악당이 "공허"라는 차원에서 몰래 침입.

## 서버 환경

- **모드팩**: Fantasy MC Fabric (PixelDreamStudios 제작), 버전 0.3.3 [BETA]
- **마인크래프트 버전**: 1.21.1
- **모드로더**: Fabric Loader 0.19.3
- **Java**: 21 (Temurin-21.0.11)
- **서버 실행 위치**: 로컬 PC (`C:\Users\hhsun\Desktop\fantasymc_fabric_1.21.1_0.3.3_server_pack`)
- **모드 개수**: 약 539개
- **향후 계획**: 로컬 테스트 → 완성도 올라가면 전용 마인크래프트 호스팅 또는 VPS로 이전 예정
  (닷홈 같은 일반 웹호스팅은 마크 서버 구동 불가 — 공유 호스팅은 상시 Java 프로세스 실행 지원 안 함)

## 중요한 결정 사항 (왜 이렇게 됐는지)

### Cardboard(Bukkit 플러그인 브릿지) 포기함
- 처음엔 Cardboard + iCommon + ServerCore로 MMOCore/MMOItems 같은 Bukkit 플러그인을 쓰려고 시도
- `knightlib`(이 모드팩의 여러 RPG 전투 모드가 의존하는 라이브러리)와 Cardboard의 mixin이
  같은 지점(`LivingEntity` 아이템 사용 이벤트)을 동시에 건드리면서 `@Redirect conflict` → 크래시 발생
- GitHub 이슈 확인 결과 Cardboard는 이런 유형의 mixin 충돌이 구조적으로 흔함 (Apoli, BCLib 등 다른 유명 모드도 비슷한 이슈 리포트됨)
- 이 모드팩은 knightlib, spell_engine 등 mixin 기반 전투 라이브러리를 쓰는 모드가 매우 많아서,
  하나 고쳐도 계속 재발할 가능성이 높다고 판단 → **Cardboard/iCommon/ServerCore 전부 제거**
- 대신 **모드팩에 이미 내장된 Fabric 네이티브 모드들로 직업/스킬 시스템 구현하는 방향으로 전환**

### 방향 전환의 근거
542개 모드 중 상당수가 이미 RPG 직업/스킬/던전/경제 시스템을 제공하고 있어서,
Bukkit 플러그인 없이도 요청 스펙을 상당 부분 커버 가능하다고 판단.

## 직업/스킬 시스템 — 확인된 것

### 핵심 모드
- **Spell Engine** (`spell_engine`): 스킬(주문) 시스템의 핵심. 데이터 드리븐 마법 라이브러리
  - GitHub: https://github.com/ZsoltMolnarrr/SpellEngine
  - 스펠북 아이템 ID: `spell_engine:book` (태그별로 자동 생성되어 이름이 여러 개 존재)
  - 스펠 스크롤 ID: `spell_engine:spell_scroll`
  - 주문 결속 탁자(Spell Binding Table) 블록 ID: `spell_engine:spell_binding`
  - 스펠북은 **Trinkets 또는 Accessories 모드의 장신구 슬롯**(`spell/book`)에 장착
  - 무기 종류별로 **기본공격 스킬이 자동 배정**됨 (검→Swift Strikes 연속베기, 도끼→Cleave 광역기,
    창→Impale 돌진, 망치→Ground Slam 등 — `rpg_series` 네임스페이스에 정의됨)
  - 스펠북에 담을 수 있는 스킬 개수는 `SpellContainer` 설정(최대 스킬 수)으로 조절 가능
    → **"기본공격 + 스킬 3개" 요구사항을 이 설정값 조정으로 구현 가능할 것으로 보임 (확인 필요)**
  - 스킬 부착 시 레벨 요구사항 + 재료 소모 + 마법부여 레벨 요구 조건이 이미 걸려있음 (인게임 확인함,
    예: "불의 책" 스킬 하나에 레벨 50, 청금석 15개, 마법부여 레벨 15 요구)
  - 설정 파일 위치 (서버 mods 폴더 기준): `config/spell_engine/`
    - `server.json5`: 스펠 메커니즘, 친적아군 로직
    - `weapon_fallback.json`: 자동 스펠 컨테이너 할당 규칙
    - `spell_container_templates.json`: 자동 할당 템플릿 (여기 스킬 최대 개수 있을 가능성 높음)
    - `fabric_compatibility.json`: Trinkets vs Accessories 우선순위

- **Skill Tree (RPG Series)** (`skill_tree_rpgs`): 직업별 스킬트리에 포인트 투자하는 시스템
  - "Orb of Oblivion" 같은 스킬포인트 초기화 아이템 확인함

- **Spell Power** (`spell_power`): 스펠 데미지 계산에 쓰이는 능력치 시스템

### 직업 후보 모드 (요청한 10개 직업 vs 확인된 모드)
아직 각 모드가 정확히 어떤 스킬/무기를 제공하는지 상세 확인 전. 이름으로 유추한 매칭:

| 요청 직업 | 후보 모드 |
|---|---|
| 전사 (검사/성기사) | `paladins`, `lne_paladins`, `oathswornpaladins` |
| 궁수 (아처/스나이퍼) | `archers`, `lne_archers`, `archers_expansion` |
| 마법사 (성직자/원소술사) | `wizards`, `lne_wizards`, `elemental_wizards_rpg` |
| 도적 (암살자/닌자) | `rogues`, `lne_rogues` |
| 해적 (무투가/거너) | 명확한 후보 안 보임, `berserker_rpg`, `forcemaster_rpg` 등 추가 조사 필요 |

**다음 세션에서 할 일**: 각 모드를 인게임에서 실제로 켜보거나 설정 파일 읽어서
정확히 뭘 제공하는지 확인하고, 어떤 조합으로 10직업을 구성할지 확정.

## 요청 스펙 vs 매칭 현황

| 요청 | 상태 | 메모 |
|---|---|---|
| 10개 직업 (전사/궁수/마법사/도적/해적×2) | 진행중 | 위 표 참고, 세부 확정 필요 |
| 스킬로 전투 (기본공격+스킬3) | 유력 | Spell Engine 구조로 가능해 보임, 슬롯 개수 설정 확인 필요 |
| 장비 강화 레벨(10렙/20렙 효과) | 후보 있음 | `easyanvils`, `easymagic`, `mythicmetals` — 미검증 |
| 화폐(페소) | 후보 있음 | `universal_shops`가 `common-economy-api` 포함 — 미검증 |
| 펫(커스텀 NPC, 죽으면 교체+쿨타임) | 후보 있음 | `companions` — 미검증 |
| 내실(도감/낚시/채광/농사) | 후보 있음 | `almanac`, `farmersdelight`, `chefsdelight`, `toms_storage` |
| 던전+반복퀘스트 | 후보 있음 | `ftbquests`, `perplayerquests`, `questkilltask`, `adventuredungeons`, `dungeonz` 등 |
| 보스 재활용 | 후보 있음 | `bosses_of_mass_destruction`, `brutalbosses`, `rpg-minibosses` 등 — 나중에 진행 예정 (요청자 확인) |
| 부동산(공터 구매) | 후보 있음 | `ftbchunks` — Fabric 네이티브 영지 클레임 |
| PvP 배팅장+관전 | **커스텀 필요** | 매칭되는 기성 모드 없음. 데이터팩/커맨드블록 또는 별도 개발 필요 |
| 공허 세계관 스토리라인 | **콘텐츠 제작 필요** | FTB Quests로 구현 예정, 텍스트/조건 작업 필요 |
| 파티클/랜덤분배 루팅 | 후보 있음 | `lootbeams`, `lootr` |
| GUI/번역 | **작업 필요** | 아래 참고 |

## 번역 작업 진행 상황 (2026-07-25~)

### 방식 확정
- **리소스팩 하나로 진행** (`resourcepacks/korean_translation_pack/`, 서버팩 루트에 위치)
- 마인크래프트 언어 로딩은 **키 단위 병합**이라, 모드가 이미 번역해둔 키는 안 건드리고
  **누락된 키만 채워 넣으면 됨** (파일 전체를 새로 만들 필요 없음)
- 리소스팩이라 **서버 mods 폴더는 안 건드려도 됨** — 클라이언트가 이 폴더만 리소스팩으로 추가하면 끝
  (단, 레시피/루트테이블/능력치 등 `data/` 영역이나 실제 로직 수정은 리소스팩으론 불가 → 데이터팩/모드 수정 필요)
- pack_format 34 (1.21.1 기준)로 `pack.mcmeta` 작성함

### 356개 모드 전수 스캔 결과 (스크립트로 en_us.json vs ko_kr.json 키 비교)
- 언어 파일 없음(라이브러리 등, 번역 불필요): 112개
- 영어만 있고 한글 전무: 184개
- 한글 있지만 일부 키 누락: 44개
- 완전 번역됨: 21개
- 누락 키 총합 대략 3만개+ (단, `rechiseled`(3656)/`the_bumblezone`(1237)/`eternalstarlight`(1788)/
  `biomeswevegone`(1169)/`minecells`(592) 등 대형 월드젠·장식 모드가 대부분 차지 — 블록/구조물 이름 위주라
  체감 우선순위 낮음, 뒤로 미룸)

### 우선순위 (플레이어가 실제로 자주 보는 텍스트 순)
1. **스킬 시스템** — `spell_engine`(185키 중 15개 누락), `rpg_series`(기본공격 스킬명 20개, 전체 누락) → **완료**
2. **직업 모드** — `paladins`/`archers`/`wizards`/`rogues`/`armory_rpgs`/`arsenal`은 이미 완역됨.
   반면 `lne_paladins`(37)/`lne_archers`(38)/`lne_rogues`(22)/`lne_wizards`(48)/`oathswornpaladins`(89)/
   `elemental_wizards_rpg`(192)/`berserker_rpg`(70)/`forcemaster_rpg`(67)/`witcher_rpg`(454)/
   `bards_rpg`(153)/`druids`(106)/`relics_rpgs`(183)/`rpg_battle_gear`(101)/`rpg-systems`(124)/
   `rpg-minibosses`(156)/`gears_of_valor`(58)/`spellbladenext`(390) 등은 미번역 — **다음 작업 대상**
3. **자주 보이는 UI** — `jade`(101 누락), `xaerominimap`/`xaeroworldmap`(미번역), `waystones`(250 누락),
   `accessories`(178, 전부 미번역), `toms_storage`(128 누락), `travelersbackpack`(22 누락)
4. **퀘스트/경제/펫/강화** — `ftbquests`(656, 공허 스토리라인용이라 중요), `companions`(264, 전부 미번역),
   `easyanvils`(24/26 누락)/`easymagic`(6/9 누락, 사실상 미완), `ftbchunks`(286 누락), `universal_shops`(완역됨)

### 완료된 파일
- `resourcepacks/korean_translation_pack/assets/spell_engine/lang/ko_kr.json` (누락 15키)
- `resourcepacks/korean_translation_pack/assets/rpg_series/lang/ko_kr.json` (전체 20키 — Cleave=휩쓸기,
  Fan of Knives=칼날 부채, Flurry=연속 타격, Ground Slam=대지 강타, Impale=관통 찌르기, Smash=강타,
  Swift Strikes=신속한 연타, Swipe=휘두르기, Thrust=찌르기 돌진, Whirlwind=회오리)
- `resourcepacks/korean_translation_pack/assets/lne_paladins/lang/ko_kr.json` (전체 37키)
- `resourcepacks/korean_translation_pack/assets/lne_archers/lang/ko_kr.json` (전체 38키)
- `resourcepacks/korean_translation_pack/assets/lne_rogues/lang/ko_kr.json` (전체 22키)
- `resourcepacks/korean_translation_pack/assets/lne_wizards/lang/ko_kr.json` (전체 48키)
- `resourcepacks/korean_translation_pack/assets/oathswornpaladins/lang/ko_kr.json` (전체 89키)
- `resourcepacks/korean_translation_pack/assets/berserker_rpg/lang/ko_kr.json` (전체 70키)
- `resourcepacks/korean_translation_pack/assets/forcemaster_rpg/lang/ko_kr.json` (전체 67키)

### 2026-07-26 배치 — 나머지 직업 후보 모드 10개 전체 완료
`elemental_wizards_rpg`(192)/`witcher_rpg`(454)/`bards_rpg`(153)/`druids`(106)/`relics_rpgs`(183)/
`rpg_battle_gear`(101)/`rpg-systems`(124)/`rpg-minibosses`(156)/`gears_of_valor`(58)/`spellbladenext`(390)
전부 `resourcepacks/korean_translation_pack/assets/<namespace>/lang/ko_kr.json`으로 번역 완료 (JSON 검증 통과).
위쳐 관련 용어는 표식(Sign)/아드·이그니·큐엔·예렌·악시(표식 이름은 음역)/학파(School) 등으로 통일.

### 2026-07-26 배치 2 — UI/퀘스트/경제/펫/강화/지도 12개 모드 전체 완료
`easymagic`(6)/`easyanvils`(24, 색상명 포함)/`jade`(101)/`travelersbackpack`(22)/`toms_storage`(128)/
`waystones`(250)/`accessories`(178, 전체)/`ftbchunks`(286)/`companions`(264, 전체)/`xaerominimap`(626, 전체)/
`xaeroworldmap`(291, 전체)/`ftbquests`(656, 전체) — 전부 `resourcepacks/korean_translation_pack/assets/<namespace>/lang/ko_kr.json`
으로 번역 완료, JSON 검증 통과. 총 22개 모드 번역 완료 (직업 모드 10개 + 이번 배치 12개).

특수 처리 사항:
- `companions`의 사설 유니코드 아이콘 문자(~ 등, 커스텀 폰트 글리프)는 번역 시 실수로 누락되어
  PowerShell로 재복구함 — 향후 이런 사설 영역(Private Use Area) 문자가 포함된 키는 특히 주의해서 보존할 것
- `toms_storage`의 tooltip.* 키들은 줄바꿈에 실제 `\n`이 아니라 리터럴 백슬래시(`\\`)를 구분자로 사용함
  (mod 자체의 툴팁 렌더러가 그렇게 파싱하는 것으로 보임) — 원본 이스케이프 패턴을 그대로 유지해 번역함

### 2026-07-26 배치 3 — 크래시 진단 + 시작 화면/퀘스트/오리진/스킬트리

**크래시 원인**: 리소스팩 적용 후 "응답없음→크래시"는 리소스팩 손상이 아니라
`java.lang.OutOfMemoryError: Java heap space` (`-Xmx4096m`으로 539개 모드+리소스팩 감당 불가).
CurseForge 런처의 Allocated Memory를 8GB 이상으로 올려서 해결 확인.

**FTB Quests 퀘스트 내용 전체 번역**: `config/ftbquests/quests/lang/en_us.snbt` 옆에
`ko_kr.snbt`를 신규 작성 (챕터/챕터그룹/퀘스트/보상/태스크 제목·부제·설명 약 400개 항목).
이 모드팩은 `data.snbt`의 `fallback_locale` 설정으로 보아 FTB Quests 자체 다국어 시스템을 이미
사용 중 — 리소스팩이 아니라 **서버 config 데이터**이므로 실제 서버에도 이 파일을 반영해야 적용됨.
장식/스페이서용 내부 코드명 태스크(`b1`, `path3`, `expand1.2` 등)는 번역하지 않고 그대로 둠.

**스타터킷("choose your Path") 화면**: `config/starterkit.json5`의 `chooseKitText`와
`config/starterkit/descriptions/*.txt`(방향키 안내문, 5개 킷 전부 동일)를 한글화.
킷 이름(Forsaken Prophet 등)은 파일명 기반 자동 포맷팅이라 이름 변경 시 다른 시스템 참조가
깨질 위험이 있어 그대로 둠. `Choose Starter Kit` 버튼 자체는 모드에 lang 파일이 없어(하드코딩)
리소스팩으로 번역 불가.

**Origins/의료벌 오리진스(medievalorigins) 번역 보완**: 별도의 종족 선택 시스템(`config/origins_server.json`
으로 활성화 확인). `medievalorigins` 모드 자체 번들 `ko_kr.json`이 최신 콘텐츠 102개 키 누락 —
`resourcepacks/korean_translation_pack/assets/medievalorigins/lang/ko_kr.json`에 누락분만 추가.
`apoli`(오리진 프레임워크)는 자체 ko_kr 번역이 아예 없어서 77개 키 전체 신규 번역 추가.
`origins` 기본 모드는 1개 키만 누락이라 같이 보완.

**skill_tree_rpgs(RPG Series 스킬트리 애드온) 전체 번역**: 모드 자체에 ko_kr.json이 아예 없어서
446개 키(효과/스킬 제목/주문 설명, `{placeholder}` 형식 유지) 전체 신규 번역.
스킬 트리 UI 프레임워크(`puffish_skills`)는 이미 자체 한글 번역이 있어 정상 표시됨.
사용자가 스크린샷에서 본 스킬 툴팁의 알 수 없는 문자열(`qr4fdarqqqm5ifoa`류)은 lang 키가 아니라
속성/모디파이어 ID가 그대로 노출되는 것으로 보이는 별개의 모드 버그 — 리소스팩으로 수정 불가,
필요시 원본 모드 개발자에게 리포트 필요.

### 2026-07-26 배치 4 — 두 번째 스킬트리 모드 + Origins 온도 파워 한계 확인

사용자가 스킬트리 스크린샷을 더 보내줘서 확인해보니, "Path of the Berserker/Earth/Water/War Archer" 등은
`skill_tree_rpgs`가 아니라 **별도의 모드** `mrpgc_skill_tree`("MRPG Classes - RPG-Series Skill Tree Add On")
소속이었음. 이 모드도 ko_kr이 전혀 없어서 432개 키(효과/스킬 제목/주문 설명) 전체 신규 번역 완료
(`resourcepacks/korean_translation_pack/assets/mrpgc_skill_tree/lang/ko_kr.json`).
바람/광전사/명사수/대지/포스마스터/툰드라 사냥꾼/전쟁 궁수/물, 총 8개 특화 경로 커버.
덤으로 `more_relics`(2키)/`more_rpg_classes`(1키)의 "Rage Power" → "분노 주문력"도 같이 보완.

각 스킬 툴팁 하단에 뜨는 알 수 없는 문자열(`7sx0m583ayw0c8yh` 류)은 번역된 스킬에도 동일하게
나타나는 것으로 재확인됨 — 번역 누락이 아니라 별개의 모드 버그(속성/모디파이어 ID가 그대로
노출되는 것으로 추정), 리소스팩으로 수정 불가.

**Origins 온도 관련 파워("Heat Shield", "Freezing Immunity") 확인**: 드워프의 "Heat Shield"와
세이렌의 "Freezing Immunity"는 `thermoo-patches` 모드가 제공하는 파워인데, 이 모드는
lang 파일이 아예 없음(en_us조차 없음) — 텍스트가 모드 Java 코드에 직접 하드코딩되어 있어
번역 키 자체가 존재하지 않음. 리소스팩/데이터팩으로 수정 불가능, 모드 디컴파일/패치가 필요한
영역이라 우선순위 낮은 한계 사항으로 기록.

### 2026-07-26 배치 5 — 몬스터 밸런싱: 협동 난이도 스케일링 활성화

**배경**: 사용자 피드백 — 이전에 서버 운영했을 때 플레이어들이 너무 쉽게 강해져서 금방 질려했음.
소규모 친구 그룹(3~8명) 기준으로 확인해보니 원인은 `config/dungeon_difficulty/difficulty_v2.json`의
`per_player_difficulty`(파티원 수에 비례해 몬스터 강해지는 협동 스케일링)가 `enabled: false`로
꺼져있었던 것 — 몹이 "혼자 상대할 몹" 기준으로 세팅되어 있어 여러 명이 같이 사냥하면 순식간에 압살됨.

**적용한 변경**: `enabled: true`로 활성화. 추가로 `counting` 값을 `EVERYWHERE`(서버 전체 접속자 수 기준
— 다른 차원에 있는 인원까지 다 세서 스케일링되는 문제 있음)에서 `DIMENSION`(같은 차원에 있는
플레이어 수만 세는 방식, 모드 소스 디컴파일로 `EVERYWHERE`/`DIMENSION` 두 값만 존재함을 확인)으로
변경 — 실제로 같이 싸우는 인원 기준에 더 가까움.
기존 던전/보스 난이도 곡선(차원별 기본 레벨, 구조물별 던전 레벨, 보스 개별 티어)은 그대로 유지
(사용자가 "기존 곡선 유지" 방향 선택).

다른 꺼진 기능(`tiered_more`의 `enableSpecialIngot`, 장비 등급별 특수 스탯 부여)은 이번엔 손대지 않음
— 필요시 논의 후 진행.

### 2026-07-28 — LevelZ 모드 커스터마이징 (Claude Code, 서버팩 직접 작업)

**배경**: LevelZ(캐릭터 레벨/스킬 시스템)를 메인 성장 시스템이 아니라, **FTB Quests 업적 달성 보상으로
Rare Candy(포션 아이템)를 받아서 올리는 서브 콘텐츠**로 쓰기로 방향 확정. 일반 플레이(사냥/채굴 등)로
경험치를 쌓거나, 레벨이 부족해서 장비를 못 쓰는 일이 없어야 함.

**적용한 변경** (`levelz-2.0.10.jar` → `levelz-2.0.10-custom.jar`로 교체, mods 폴더 서버/클라이언트 양쪽):
- `levelz.mixins.json`에서 `misc.BrewingRecipeRegistryMixin` 제거 → Strange Potion(네더의 별+용의 숨결)
  브루잉 레시피 비활성화. Rare Candy는 원래도 기본 드랍/레시피 없음 — 둘 다 "특별 배포 전용" 아이템화 완료.
  (필수 의존 모드 `libz-1.1.0.jar` 추가 설치함)
- `config/levelz.json5` (서버+클라이언트 양쪽 동일하게):
  - 모든 경험치 획득 배율(`mobXPMultiplier`, `oreXPMultiplier`, `fishingXPMultiplier`,
    `breedingXPMultiplier`, `furnaceXPMultiplier`, `tradingXPMultiplier`, `dragonXPMultiplier`,
    `bottleXPMultiplier`) → 0, `spawnerMobXP` → false. 일반 플레이로는 레벨업 완전 불가,
    Rare Candy(내부적으로 `addLevelExperience` 직접 호출, 배율 영향 안 받음)로만 레벨업 가능.
  - `restrictions` / `defaultRestrictions` → false. 스킬 레벨 미달로 아이템/블록 사용·채굴·크래프팅·
    인챈트가 막히는 기능 전체 비활성화 (코드 확인: `RestrictionLoader`가 이 두 필드를 직접 참조,
    꺼지면 제한 데이터 자체가 로드 안 돼서 `SkillRestrictionScreen`의 "다이아 곡괭이 Lv15부터 사용"
    같은 안내 목록도 자동으로 빈 화면이 됨 — 별도 조치 불필요, 재시작만 하면 반영).
  - `showLevel` / `showLevelList` / `inventorySkillLevel` → false. 인벤토리 화면의 XP/레벨 숫자 표시 제거
    (client only 옵션이라 **플레이어 배포용 모드팩에도 이 config 파일을 같이 포함해야** 전원 적용됨).
- 스킬의 "레벨 X 도달 시 능력 해금"(bonus) 목록 자체는 안 건드림 — 이건 restrictions랑 별개 시스템이고,
  이번 요청 범위 밖으로 확인됨 (사용자가 말한 건 위 restrictions 쪽이었음).

**트러블슈팅 기록**: PowerShell `Compress-Archive`로 jar 재압축 시 zip 엔트리 경로 구분자가
백슬래시(`\`)로 들어가는 버그 발견 → Java 클래스로더가 `net\levelz\...`를 못 읽어서 전체 mixin 로딩
실패, 서버 크래시남. `.NET System.IO.Compression.ZipArchive`로 직접 만들어서 해결
(슬래시 강제 변환). **mod jar 재압축은 앞으로 이 방식으로만 할 것, Compress-Archive 금지.**

- `pointsPerLevel` 3 → 1. Rare Candy 하나 = 전체레벨 +1 = 스킬 포인트 지급인데, 원래 레벨당 3포인트라
  Rare Candy 하나로 3포인트씩 나갔음 → 하나당 1포인트로 조정.

**남은 것**: Rare Candy 실제 배포 경로(상점/퀘스트보상/커스텀 루트테이블) 미정 — FTB Quests 보상 설계 때 같이 결정.

**참고**: 룬 강화 모드(`tiered_more` + `kevs-tieredz-modifiers`)도 이 세션에서 별도로 조사함 —
룬은 던전 상자 루트테이블 삽입으로 획득(크래프팅 레시피 없음), 임프린트 효과는 룬 생성 시점에
랜덤 고정되어 이후 안 바뀜, 재련은 모루 UI에 추가된 탭에서 진행. Tiered 계열에 "미스틱" 등급은 없음
(모드팩 전체 검색해도 등급명으로는 안 나옴 — 어디서 봤는지 미확인).

### 2026-07-28 (2) — starterkit "Choose Starter Kit" 버튼 한글화 + LevelZ XP/레벨/포인트 텍스트 제거

**starterkit 버튼 텍스트**: `config/starterkit.json5`(`chooseKitText`)와 방향키 안내문 5개는 config 값이라
바로 한글화. "Choose Starter Kit" 버튼만 lang 파일이 없는 완전 하드코딩이라, 클래스 파일의
UTF8 상수(`Choose Starter Kit` → `시작 키트 선택`)를 바이트 단위로 직접 패치함
(`com/natamus/starterkit_common_fabric/inventory/StarterKitInventoryScreen.class`).
**배포용 파일명은 원래 이름 그대로 유지**(`starterkit-1.21.1-8.0.jar`, "-custom" 접미사 안 붙임) —
유저들이 기존 파일을 덮어쓰기만 하면 되도록. 서버/클라이언트 mods 폴더 반영 완료 +
배포용 사본을 `마크 모드` 폴더 루트(mods 폴더 밖)에도 보관.

**LevelZ Xp/Level/Points 텍스트 제거**: `LevelScreen`에 뜨는 "Xp 0/50", "Level 1", "Points 1"은
`showLevel`/`showLevelList`/`inventorySkillLevel` config와는 무관하게 무조건 렌더링되는 걸 확인
(그 옵션들은 다른 HUD 표시용으로 추정). 해결은 lang 값 자체를 빈 문자열로 변경:
`text.levelz.gui.level`, `text.levelz.gui.points`, `text.levelz.gui.current_xp` → `""`.
개별 스킬칸의 `0/20` 같은 진행도 표시는 안 건드림(다른 키, `current_level`). 서버/클라이언트 반영 완료.

### 2026-07-28 (3) — Rare Candy 툴팁 설명줄 추가 (신규 코드 컴파일)

기존 LevelZ에는 아이템에 커스텀 설명을 붙이는 기능이 아예 없어서(RareCandyItem 자체에 툴팁 로직 없음),
lang 값 수정만으로는 불가능 — 실제로 새 클래스를 추가해서 컴파일함.

**방법**: LevelZ가 이미 `ItemTooltipCallback`(Fabric API 이벤트, Mixin 아님)으로 제한사항 툴팁을
붙이는 걸 보고 동일 패턴 적용. 서버 캐시에 있는 intermediary 매핑 마인크래프트 서버 jar
(`.fabric/remappedJars/minecraft-1.21.1-0.19.3/server-intermediary.jar`)를 클래스패스로 써서
Jabba가 설치해둔 JDK(`~/.jabba/jdk/temurin@21.0.11`)의 `javac`로 새 클래스를 직접 컴파일함
(주의: PowerShell로 컴파일할 것 — git-bash에서 세미콜론 구분 classpath를 넘기면 POSIX 경로가
제대로 변환 안 돼서 전부 "package does not exist" 에러남).

새 파일: `net/levelz/init/RareCandyTooltipInit.java` (client entrypoint로 fabric.mod.json에 추가) —
`ItemTooltipCallback.EVENT.register`로 Rare Candy에 `item.levelz.rare_candy.desc` lang 키 텍스트를 붙임.
컴파일에 필요했던 클래스패스: server-intermediary.jar, fabric-loader-0.19.3.jar,
fabric-item-api-v1(.fabric/processedMods), fabric-api-base(위와 동일 폴더), brigadier-1.3.10.jar(전이 의존성),
levelz-2.0.10-custom.jar 자체(ItemInit.RARE_CANDY 참조용).

**검증**: 서버를 직접 백그라운드로 부팅시켜서 mixin 적용/모드 로딩/월드 준비까지 에러 없이
정상 진행되는 것 확인함(단, 이 새 코드는 client entrypoint라 서버는 애초에 실행 안 함 —
서버 테스트는 "적어도 모드 로딩 자체는 안 깨졌다"만 보장, 실제 툴팁 동작은 클라이언트에서
직접 게임 켜서 Rare Candy 위에 마우스 올려 확인 필요).

### 2026-07-28 (4) — Tiered 모드 도감/각인 그룹 완전 한글화 + 룬 교환권 시스템

**룬 교환권 데이터팩** (`마크 모드/datapacks/rune_vouchers/`): 상점에서 룬을 등급별 고정가(일반 1골드/
희귀 2골드/상점전용 azure·radiant·tidal 미정가)로 개별 판매하기 위해, 염료 아이템 기반 교환권 13종 +
진행도(advancement) 트리거 + give 함수로 구현. `minecraft:consumable`은 1.21.2+ 전용이라 1.21.1에서는
`food={nutrition:0,saturation:0,can_always_eat:true}`로 대체. 진행도는 완료 후 자동 revoke 추가해서
반복 사용 가능하게 함. 싱글/서버 양쪽 `world/datapacks/`에 배포 완료, 실제 게임 테스트로 작동 확인함.

**Tiered 도감(Codex) 완전 한글화**: `data/tiered/imprint/*.json`(25개)의 `group` 필드와
`data/tiered/reforge_material/*.json`(룬 7개)의 `imprint_group(s)` 필드를 전부 한글로 변경
(combat→전투, weapon→무기, defense→방어, movement→이동, vitality→생명력, survival→생존,
magic→마법, ranged→원거리, all→전체). 룬-각인 매칭은 문자열 완전일치라 양쪽 다 같이 바꿔야 함.
도감 UI의 "Value"/"Group"/"Grants"/"Max stacks" 라벨은 lang 키가 아니라 코드에 하드코딩된 문자열이라
(`ImprintCodexTab.class`/`EffectCodexTab.class`/`CodexScreen.class`) UTF8 상수 바이트 패치로 한글화
("수치"/"종류"/"부여"/"최대 중첩"). `tiered_more-fabric-1.2.3.jar`(2026-07-28: 배포 편의상 "-custom" 접미사 제거,
원본 파일명 그대로 덮어쓰는 방식으로 통일),
`kevs-tieredz-modifiers-1.1.6.jar`(2026-07-28: 마찬가지로 "-custom" 제거)로 교체, 원본은 `마크 모드` 폴더에 보관.

등급 표시명도 "유니크"→"미스틱"으로 변경함 (내부 id는 `unique` 그대로,
`korean_translation_pack/assets/tiered/lang/ko_kr.json`의 라벨만 교체).

전체 룬/각인/드랍확률 정리 문서: `마크 모드/Tiered_룬_각인_정리.md` (직접 참고/편집용).

### 2026-07-28 (5) — kevs 추가 각인 22종 그룹 번역 + 크로스모드 속성 번역 + 재련 문구/교환권 설명

**누락됐던 각인 22종 발견 및 수정**: 앞서 "25종"으로 카탈로그한 건 tiered_more 베이스 각인만이었고,
`kevs-tieredz-modifiers`가 자기 네임스페이스(`data/kevs-tieredz-modifiers/imprint/*.json`, 7개)와
spell_engine 호환용 내장 오버라이드팩(`resourcepacks/b_spellengine_compat/data/kevs-tieredz-modifiers/imprint/*.json`,
15개)으로 각인을 추가로 얹고 있었음. 유저가 도감에서 "종류: combat/weapon/movement" 등 영문이 남아있는
스크린샷을 보내 발견함. 22개 파일의 `group` 필드를 전부 한글로 번역하고 jar 재빌드/재배포함.

**크로스모드 속성 번역**: 유저가 스크린샷으로 찾아준 미번역 텍스트 3건 추가 번역
(`critical_strike` 모드 — 인첸트/이펙트/물약 이름 18개, `kevslibrary` — 사망 메시지+속성 이름 약 45개,
`kevs_attributes_panel` — Shift 눌렀을 때 나오는 상세설명 패널 약 85개: config UI 텍스트 + 속성별 설명).

**재련 화면 문구 정리 + 룬 lore 재정리**: `screen.tiered.reforge.material.*` 배지 문구 중
인자 순서가 꼬여 있던 것들 수정 —
`favor`(강철 룬): "3.0에 대해 확률 Rare배" → "%2$s 등급 확률 %1$s배" (위치 지정자로 순서 교정),
`rarity_boost`(호박/잔불): "더 희귀한 아이템" → "등급업 확률",
`max_rarity`(사암): 그냥 "%s" → "최대 제련 %s",
`min_rarity`(잔불): 그냥 "%s" → "최소 %s 보장",
`standalone`(흑요석 전용): "단독 사용 가능" → "재료 소모 X".
단, `favor`/`min_rarity`/`max_rarity`가 표시하는 등급 이름 자체("Rare"/"Uncommon")는 lang 키가 아니라
`ReforgeMaterialTooltip.class`에 하드코딩된 `capitalize()` 호출 결과라 lang 파일로는 못 고침
(등급 이름까지 한글화하려면 해당 메서드 바이트코드 자체를 새로 컴파일해서 갈아끼워야 함 — 아직 미착수).

룬 13종의 `item.tiered.rune_*.lore`(아이템 위에 뜨는 flavor 텍스트)를 유저가 `Tiered_룬_각인_정리.md`에서
직접 정리해둔 기능 설명 문구로 전부 교체(시적 flavor text → 실제 효과 요약).

**룬 교환권 설명 추가**: 교환권 13종의 lore를 "우클릭하여 사용" → 실제 효과 설명으로 교체
(예: 광휘의 룬 교환권 = "[등급 유지] 마법 각인 1~2, 생존 각인 0~1개 부여"). `[등급 유지]` 태그는
`skip_reforge: true`인 8종(흑요석/비전/진홍/그림자/서리/짙푸른/광휘의/조류의)에만 붙임 — 나머지 5종
(호박/잔불/사암/강철/신록)은 재련 시 실제로 등급을 다시 굴리는 재료라 태그 미부착.
`datapacks/rune_vouchers/교환권_지급명령어.txt`에 갱신함 — 이미 상점에 진열된 기존 교환권은
새 명령어로 재발급해야 새 설명이 반영됨(스냅샷이라 자동 갱신 안 됨).

### 다음 남은 후보 (선택 사항, 우선순위 낮음)
직업 모드 중 매칭 후보였으나 아직 최종 확정 안 된 나머지들, 그리고 대형 월드젠/장식 모드
(`rechiseled`, `the_bumblezone`, `eternalstarlight`, `biomeswevegone`, `minecells` 등, 블록/구조물 이름 위주라 우선순위 낮음)

### 스캔 스크립트
전체 모드 lang 파일 재스캔이 필요하면: 각 jar를 zip으로 열어
`assets/<ns>/lang/en_us.json`과 `ko_kr.json`의 키셋을 비교하는 PowerShell 스크립트 사용
(스크래치패드에 `scan_lang.ps1`로 작성했었음, 결과는 `lang_scan_results.csv`)

## 다음에 할 일 (우선순위 순) — 2026-07-25 업데이트

> PvP 배팅장은 당분간 보류. **번역 작업이 최우선**, 그 다음이 게임 시스템(직업/스킬/강화/경제/펫 등).

1. **번역 작업** — 전체 모드(356개) jar의 lang 파일 점검, 누락된 `ko_kr.json` 키 채워서 리소스팩으로 배포
   (클라이언트는 리소스팩만 추가하면 됨, 서버 mods 폴더 동기화 불필요)
2. Spell Engine 설정 파일 열어서 스펠북 최대 스킬 슬롯 수 확인/조정
3. 직업별 후보 모드 실제 인게임 테스트 → 10직업 최종 확정
4. 확정된 스펙으로 각 직업별 스킬 3개 + 기본공격 조합 설계
5. 장비 강화(`easyanvils`/`easymagic`), 경제(`universal_shops`), 펫(`companions`) 모드 각각 실제 테스트
6. FTB Quests로 공허 세계관 스토리라인 및 반복 퀘스트 제작
7. (보류) PvP 배팅장 — 기성 모드 없으므로 데이터팩 또는 커스텀 개발 방식 검토, 요청자 확인 후 재개

## 참고 링크
- Spell Engine GitHub: https://github.com/ZsoltMolnarrr/SpellEngine
- Cardboard GitHub (참고용, 현재 미사용): https://github.com/CardboardPowered/cardboard
