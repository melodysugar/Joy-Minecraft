give @s tiered:rune_azure
advancement revoke @s only rune_vouchers:redeem_azure
