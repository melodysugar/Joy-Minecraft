give @s tiered:rune_ember
advancement revoke @s only rune_vouchers:redeem_ember
