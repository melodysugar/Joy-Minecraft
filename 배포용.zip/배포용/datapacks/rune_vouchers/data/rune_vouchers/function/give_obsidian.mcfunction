give @s tiered:rune_obsidian
advancement revoke @s only rune_vouchers:redeem_obsidian
