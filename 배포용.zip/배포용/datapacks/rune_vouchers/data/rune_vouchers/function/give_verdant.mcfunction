give @s tiered:rune_verdant
advancement revoke @s only rune_vouchers:redeem_verdant
