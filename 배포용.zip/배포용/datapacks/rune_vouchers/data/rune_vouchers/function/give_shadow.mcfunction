give @s tiered:rune_shadow
advancement revoke @s only rune_vouchers:redeem_shadow
