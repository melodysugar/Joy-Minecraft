give @s tiered:rune_tidal
advancement revoke @s only rune_vouchers:redeem_tidal
