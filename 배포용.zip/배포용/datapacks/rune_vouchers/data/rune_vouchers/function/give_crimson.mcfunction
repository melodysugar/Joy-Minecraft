give @s tiered:rune_crimson
advancement revoke @s only rune_vouchers:redeem_crimson
