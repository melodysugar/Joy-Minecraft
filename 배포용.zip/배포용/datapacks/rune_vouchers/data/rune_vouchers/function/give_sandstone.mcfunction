give @s tiered:rune_sandstone
advancement revoke @s only rune_vouchers:redeem_sandstone
