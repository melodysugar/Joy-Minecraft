give @s tiered:rune_steel
advancement revoke @s only rune_vouchers:redeem_steel
