give @s tiered:rune_frost
advancement revoke @s only rune_vouchers:redeem_frost
