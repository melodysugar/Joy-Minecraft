give @s tiered:rune_amber
advancement revoke @s only rune_vouchers:redeem_amber
