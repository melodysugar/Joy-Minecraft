give @s tiered:rune_arcane
advancement revoke @s only rune_vouchers:redeem_arcane
