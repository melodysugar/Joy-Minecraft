give @s tiered:rune_radiant
advancement revoke @s only rune_vouchers:redeem_radiant
