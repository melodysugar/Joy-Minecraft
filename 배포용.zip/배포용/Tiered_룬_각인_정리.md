# Tiered 모드 — 룬/각인/재련 시스템 정리

> **2026-07-28부터 원본 jar 대신 커스텀 버전 사용 중**:
> `tiered_more-fabric-1.2.3.jar`(원본 파일명 그대로, 배포 시 덮어쓰기용), `kevs-tieredz-modifiers-1.1.6.jar`(마찬가지로 "-custom" 제거)
> (마크 모드 폴더 루트에 원본+작업폴더(`extracted_tiered`/`extracted_kevs`) 보관됨)
>
> 데이터 출처: `tiered_more-fabric-1.2.3.jar`, `kevs-tieredz-modifiers-1.1.6.jar`
> 실제 파일 위치(서버 mods 폴더 기준):
> - 각인 정의: `data/tiered/imprint/*.json` (tiered_more jar 안)
> - 룬(재련재료) 정의: `data/tiered/reforge_material/*.json`
> - 효과 정의: `data/tiered/effect/*.json`
> - 룬 드랍 테이블: `data/tiered/rune_injection/*.json`
> - 튜닝잉곳 설정: `config/tiered_more/tiered_more.json` (서버에서 직접 수정 가능한 실제 config)
> - 한글 번역: `korean_translation_pack/assets/tiered/lang/ko_kr.json`, `assets/kevs-tieredz-modifiers/lang/ko_kr.json`

이 문서는 jar 안 원본 데이터를 그대로 옮겨적은 "참고용"입니다. 실제 값을 바꾸려면 위 경로의 원본 파일을 고쳐야 게임에 반영됩니다 (이 문서 자체를 고치는 건 기록용일 뿐).

---

## 1. 등급(희귀도) 체계

| 영문 | 한글 표시 |
|---|---|
| Common | 일반 |
| Uncommon | 고급 |
| Rare | 레어 |
| Epic | 에픽 |
| Legendary | 레전더리 |
| Unique | 미스틱 (2026-07-28부터 "유니크"→"미스틱"으로 표시명 변경, 내부 id는 여전히 unique) |

튜닝 잉곳(등급 조율용 소모템) 상자 드랍 확률 (`config/tiered_more/tiered_more.json` → `tuningIngotConfigs`):

| 등급 | 드랍 확률(상자당) | 개수 |
|---|---|---|
| 일반 | 30% | 1~5개 |
| 고급 | 20% | 1~4개 |
| 레어 | 15% | 1~3개 |
| 에픽 | 7.5% | 1~2개 |
| 레전더리 | 3.5% | 1~2개 |
| 미스틱 | 1% | 1개 |

적용 상자: 던전, 폐광, 바스티온(다리/외양간/기타/보물), 매장보물, 난파선, 사막신전, 정글사원, 삼림저택, 스트롱홀드(복도/서재/교차로), 엔드시티, 네더요새

---

## 2. 룬(재련 재료) 목록 — 13종

각 룬은 재련대(모루 Reforge 탭)에서 재료로 쓰는 소모 아이템. 아래 표는 원본 JSON 그대로.

### 기본 10종 (tiered_more)

| 룬 (한글) | item id | color | 설명(lore) | 핵심 속성 | 비고 |
|---|---|---|---|---|---|
| 호박 룬 | `tiered:rune_amber` | gold | 가장 희귀한 제련 룬. | `rarity_boost: 0.85` | 재련 시 85% 확률로 등급 상승 유도, 효과풀(안정화/과충전) 부여 |
| 잔불의 룬 | `tiered:rune_ember` | red | 재련 시 최소 레어등급이 보장됩니다. | `rarity_boost: 0.3`, `guaranteed_min_rarity: rare` | 30% 등급상승 + 최소 레어 보장 |
| 사암 룬 | `tiered:rune_sandstone` | yellow | 고급 이하로만 재련. | `max_rarity: uncommon` | 결과를 고급 이하로 제한 |
| 강철 룬 | `tiered:rune_steel` | gray | 레어 등급 재련 확률 3배. | `group_weight_multipliers: {rare: 3.0}` | 레어 그룹 가중치 3배 |
| 청록의 룬(verdant) | `tiered:rune_verdant` | green | 내구도 일정 수리와 무작위 각인 0~1개 부여됩니다. | `effects: [tiered:mend]`, 각인풀(강화 각인) | 수리 + 강화(내구도) 각인 부여 |
| 흑요석 룬 | `tiered:rune_obsidian` | dark_gray | 각인 추출, 새 룬 슬롯 부여 중 능력 부여 | `skip_reforge`, `skip_base_item` | 등급 안 건드림, 효과 둘 중 하나(추출 66%/슬롯부여 33%) |
| 비전 룬 | `tiered:rune_arcane` | light_purple | 무작위 각인 1~3개 부여. | `skip_reforge`, imprint_pool(전체 그룹) 1~3개 | 몹 체력 비례 각인 개수 증가 |
| 진홍의 룬 | `tiered:rune_crimson` | dark_red | 무기 각인 1~2, 공격 각인 1~2개 부여. | `skip_reforge`, imprint_pools(무기+전투) 각 1~2개 | |
| 그림자 룬 | `tiered:rune_shadow` | dark_purple | 이동 각인 1~3개 부여. | `skip_reforge`, imprint_pool(이동) 1~3개 | |
| 서리 룬 | `tiered:rune_frost` | aqua | 생명력, 생존, 방어 각인 중 2개 부여 | `skip_reforge`, 3가지 조합 중 랜덤(방어+생명력 / 생명력+생존 / 방어+생존) | |

### 상점 전용 3종 (kevs-tieredz-modifiers, 자연 드랍 없음)

> 교환권 이름을 아이템 공식 명칭(모드 번역)에 맞춰 통일함 (2026-07-28).

| 룬 (한글, 교환권 이름과 동일) | item id | color | 설명(lore) | 핵심 속성 |
|---|---|---|---|---|
| 짙푸른 룬 | `tiered:rune_azure` | blue | 마법 각인 1~2개 부여 | `skip_reforge`, imprint_pool(마법) 1~2개 |
| 광휘의 룬 | `tiered:rune_radiant` | white | 마법 각인 1~2, 생존 각인 0~1개 부여 | `skip_reforge`, imprint_pool(마법 1~2 + 생존 0~1) |
| 조류의 룬 | `tiered:rune_tidal` | aqua | 원거리 각인 1~2개 부여 | `skip_reforge`, imprint_pool(원거리) 1~2개 |

### 기타 재련 재료

| 이름 | item id | 설명(lore) | 비고 |
|---|---|---|---|
| 자수정 조각 | `minecraft:amethyst_shard` | 표준 재련 재료입니다. | 특수효과 없는 기본 수리/등급굴림용 |

---

## 3. 룬 드랍 테이블 (자연 드랍, `data/tiered/rune_injection/*.json`)

10종 기본 룬만 해당 (상점 전용 3종은 자연 드랍 없음).

| 소스 파일 | 적용 위치 | 발동확률 | 개수 | 희귀 4종 가중치 | 일반 6종 가중치 |
|---|---|---|---|---|---|
| `boss_runes.json` | #c:bosses 태그 몹 | 60% | 1~6개 | 2 | 3 |
| `dungeon_runes.json` | 던전/폐광/스트롱홀드/정글사원/사막신전/약탈자전초기지 | 12% | 1~2개 | 1 | 3 |
| `endgame_runes.json` | 고대도시/엔드시티보물/바스티온보물 | 25% | 1~4개 | 2 | 3 |
| `village_runes.json` | 마을상자/영웅의마을 | 8% | 1개만 | (없음) | 1 |

- 희귀 4종: crimson(진홍), arcane(비전), shadow(그림자), frost(서리)
- 일반 6종: amber(호박), ember(잔불), obsidian(흑요석), sandstone(사암), steel(강철), verdant(청록)

---

## 4. 재련 효과(Effect) 목록 — `data/tiered/effect/*.json`

룬의 `effect_pools`/`effects` 필드에서 참조하는 재련 시 발동 효과.

| id | 한글 이름 | 설명 |
|---|---|---|
| `tiered:stabilize` | 안정화 | 현재 등급보다 낮게 나오지 않음 |
| `tiered:overcharge` | 과충전 | 기본 재료 추가 소모, 레어 이상 보장 + 등급상승 확률 크게 증가 |
| `tiered:extract` | 추출 | 아이템의 각인 하나를 이 룬으로 옮김 |
| `tiered:forget` | 망각 | 모든 각인 + 아이템 등급 초기화 |
| `tiered:mend` | 수리 | 최대 내구도의 일정 비율 회복 |
| `tiered:grant_rune_slot` | 룬 슬롯 부여 | 무기/방어구에 룬 슬롯 1개 추가 (재료 자체는 슬롯 안 차지) |

---

## 5. 각인(Imprint) 목록 — 25종 (`data/tiered/imprint/*.json`)

무기/방어구에 재련으로 새겨지는 영구 효과. `group`으로 분류되고, 룬의 `imprint_group`/`imprint_groups` 필드가 이 그룹명을 참조함.

> **2026-07-28 업데이트**: `group` 필드 값 자체를 한글로 변경함 (combat→전투 등, 아래 표에 반영됨).
> 도감(Codex) UI의 "Value"/"Group"/"Grants"/"Max stacks" 라벨도 바이트 패치로 한글화함
> ("수치"/"종류"/"부여"/"최대 중첩") — 이건 lang 파일이 아니라 코드에 박혀있던 텍스트라 jar 직접 수정함.

| id | 한글 이름 | group | 값 범위 (value_min~max) | 중첩상한(max_bonus) | 비고 |
|---|---|---|---|---|---|
| `affliction` | 환난 | 전투 | 7.5%~15% | 100% | 상태이상 피해 증가, 지속 10~20초(최대40) |
| `airborne` | 공중전 | 이동 | 1%~5% | 50% | 공중에 떠있을 때 피해량 |
| `bloodthirst` | 흡혈 | 전투 | 1%~10% | 35% | 가한피해 10% 회복 확률 |
| `condemned` | 단죄 | 전투 | 3%~5% | 20% | 디버프 4개 이상시 배율 1.2배 |
| `crushing` | 분쇄 | 무기 | 1%~5% | 50% | 철퇴(mace) 전용 |
| `executioner` | 처형자 | 전투 | 0.5~1.0(raw) | 3.0 | 처치 시 체력 회복(하트 단위) |
| `flanking` | 측면공격 | 무기 | 3%~8% (페널티 -2%~-5%) | 30%(페널티 -15%) | 배후/정면 각도 120°/60° |
| `fortified` | 방비 | 방어 | 0.25~1.0(속성) | 10.0 | 방어력 속성치 직접 증가 |
| `honed` | 연마 | 무기 | 1%~5% | 50% | 검(sword) 전용 |
| `last_stand` | 최후의 저항 | 전투 | 7.5%~15% | 65% | 체력 35% 이하일 때 |
| `momentum` | 탄력 | 전투 | 5%~10% | 25% | 동일대상 중첩, 최대5스택/60틱 리셋 |
| `piercing` | 관통 | 무기 | 1%~5% | 50% | 삼지창(trident) 전용 |
| `ravenous` | 탐식 | 생명력 | 2.5%~7% | 35% | 허기 가득 시, 포만감 있으면 최대1.5배 |
| `reinforced` | 강화 | (없음) | 10%~25% | - | 최대 내구도 증가 |
| `rending` | 찢기 | 무기 | 1%~5% | 50% | 도끼(axe) 전용 |
| `retaliation` | 반격 | 전투 | 5%~15% | 35% | 피격 후 다음 공격, 지속100틱 |
| `second_wind` | 회생 | 생존 | 5%~10% | 65% | 체력35%이하, 재사용대기 300틱 |
| `soul_harvest` | 영혼수확 | 전투 | (없음, 고정) | - | 처치시 힘효과, 최대 duration 400틱 |
| `stalwart` | 불굴 | 방어 | 1%~2% | 10% | 내구도 소모 무시 확률 |
| `swiftness` | 신속 | 이동 | 3%~6%(속성) | 15% | 이동속도 배율 증가 |
| `tempered` | 담금질 | 방어 | 2%~5% | 50% | 내구도 소모량 감소 |
| `thorns_aura` | 가시 오라 | 방어 | 5%~15% | 45% | 공격자에게 반사, 최소피해0.5 |
| `tormented` | 고문 | 전투 | 0.5%~1.5% | 7.5% | 대상 디버프 단계당 |
| `velocity` | 가속 | 이동 | 1%~5% | 50% | 질주 중 피해량 |
| `vigorous` | 활력 | 생명력 | 1.0~3.0(속성) | 30.0 | 최대체력 직접 증가 |
| `wither_strike` | 위더의 일격 | 전투 | (없음, 고정) | - | 타격시 위더효과, 지속60틱 |

**무기 전용 각인 적용 조건**: crushing→철퇴, honed→검류, piercing→삼지창, rending→도끼류 (해당 무기 아니면 발동 안 함)

---

## 6. 참고 — 각인 그룹(group) 목록

룬의 `imprint_group`이 참조하는 카테고리 값 (2026-07-28부터 실제 데이터 값도 한글로 변경됨):
- **전투**(구 combat) — affliction, bloodthirst, condemned, executioner, last_stand, momentum, retaliation, soul_harvest, tormented, wither_strike, deadeye, hunters_focus
- **무기**(구 weapon) — crushing, flanking, honed, piercing, rending, resonance
- **방어**(구 defense) — fortified, stalwart, tempered, thorns_aura
- **이동**(구 movement) — airborne, swiftness, velocity
- **생명력**(구 vitality) — ravenous, vigorous
- **생존**(구 survival) — second_wind
- **마법**(구 magic) — ~~상점전용 룬만 사용~~ **정정(07-28): kevs spellengine 호환 각인 12개가 실제로 사용** (aeromancy, arcanist, channeling, cryomancy, druidry, galvanism, geomancy, hydromancy, mending_grace, mending_light, pyromancy, soulreaper, spell_surge)
- **원거리**(구 ranged) — ~~상점전용 조류 룬만 사용~~ **정정(07-28): culling_shot, marksman, quickdraw도 사용**
- **전체**(구 all) — 비전 룬 전용

이 값들은 룬의 `imprint_group`/`imprint_groups` 필드(`data/tiered/reforge_material/*.json`)와
각인의 `group` 필드(`data/tiered/imprint/*.json`)가 **정확히 문자열이 일치**해야 매칭되므로,
둘 중 하나만 고치면 안 되고 항상 같이 바꿔야 함.

### 6-1. kevs-tieredz-modifiers가 추가하는 각인 22종 (2026-07-28 발견, 처음 조사 때 누락됨)

기존 "25종"은 tiered_more 베이스 각인만 센 것이고, kevs-tieredz-modifiers가 자체 네임스페이스로
훨씬 많은 각인을 추가로 얹고 있었음. 파일 위치가 또 특이함:

| 위치 | 각인 목록 | 개수 |
|---|---|---|
| `data/kevs-tieredz-modifiers/imprint/*.json` (kevs jar 자체) | barbed, culling_shot, deadeye, hunters_focus, marksman, quickdraw, resonance | 7개 |
| `resourcepacks/b_spellengine_compat/data/kevs-tieredz-modifiers/imprint/*.json` (kevs jar 내장 덮어쓰기팩, spell_engine 호환용) | aeromancy, arcanist, attuned, channeling, cryomancy, druidry, galvanism, geomancy, hydromancy, mending_grace, mending_light, pyromancy, sanctified, soulreaper, spell_surge | 15개 |

**"공명"(resonance)** 같은 특수 각인은 "연마 + 공명 = 전투 광란"처럼 두 각인 조합으로 별도 효과가 붙는
콤보 시스템도 있음 (자세한 수치는 각 파일 참고, 아직 표로 안 옮김).

⚠️ **이 22개는 group 필드만 한글화했고, 값 범위(value_min/max)나 이름/설명 세부 번역까지는
아직 이 문서에 정리 안 함** — 필요하면 추가로 진행 가능.

---

## 7. 수정할 때 참고사항

- 각인 값(`value_min`/`value_max`/`max_bonus`) 수정 → `data/tiered/imprint/<이름>.json`의 `types[0]` 안 숫자 변경
- 룬의 등급상승 강도(`rarity_boost`) 수정 → `data/tiered/reforge_material/<룬이름>.json`
- 드랍 확률 수정 → `data/tiered/rune_injection/*.json`(룬), `config/tiered_more/tiered_more.json`(튜닝잉곳)
- 이름/설명 번역 수정 → `korean_translation_pack/assets/tiered/lang/ko_kr.json`
- 값 수정 후 재시작 또는 `/reload` 필요 (데이터팩 위치 파일 기준)
